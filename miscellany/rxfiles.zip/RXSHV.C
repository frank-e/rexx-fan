/* -------------------------------------------------------------------- *
 *                                                                      *
 * PC DOS 7 REXX Shared Variable Interface access example (C version):  *
 *                                                                      *
 * Make RXSHV.EXE from RXSHV.C, rename RXSHV.EXE to RXSHV.RX, put it in *
 * a directory, where REXX will find it (e.g. PATH). In a REXX script   *
 * call RXSHV to examine and modify SHV interactively.                  *
 *                                                                      *
 * -------------------------------------------------------------------- */

#include <string.h>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>

#define RXSHV_SET       0x00    /* set variable from given value        */
#define RXSHV_FETCH     0x01    /* copy value of variable to buffer     */
#define RXSHV_DROPV     0x02    /* drop variable name                   */
#define RXSHV_SYSET     0x03    /* symbolic name set variable           */
#define RXSHV_SYFET     0x04    /* symbolic name fetch variable         */
#define RXSHV_SYDRO     0x05    /* symbolic name drop variable          */
#define RXSHV_NEXTV     0x06    /* get next variable                    */
#define RXSHV_PRIV      0x07    /* fetch private information            */
#define RXSHV_EXIT      0x08    /* set exit code (not in personal REXX) */

#define RXSHV_OK        0x00    /* execution was ok                     */
#define RXSHV_NEWV      0x01    /* variable did not exist               */
#define RXSHV_LVAR      0x02    /* last variable transferred            */
#define RXSHV_TRUNC     0x04    /* truncation occurred during "fetch"   */
#define RXSHV_BADN      0x08    /* invalid variable name                */
#define RXSHV_MEMFL     0x10    /* memory resources exhausted           */
#define RXSHV_BADF      0x80    /* invalid function code (shvcode)      */

#ifndef MK_FP
#define MK_FP( s, o ) (((_segment)(s)):>((void _based(void) *)(o)))
#endif

#pragma pack( 1 )

struct RXSTR                            /****** REXX string format ******/
{       unsigned int  StrLen;           /* string length                */
        char _far *   StrPtr;           /* string pointer               */
};

static struct RX_PSP                    /**** REXX PSP informations: ****/
{       char               Fill1[ 84 ]; /*                              */
        char               Rexx[ 4 ];   /* signature "REXX" at PSP:54h  */
        void ( _far *RXcall )( struct SHVBLOCK _far * );        /* call */
        char               Fill2[ 38 ]; /*                              */
        unsigned int       RXargc;      /* Counter of REXX arguments    */
        struct RXSTR _far *RXargv;      /* Pointer to REXX arg. strings */
        char _far *        RXresult;    /* Pointer to RESULT, 256 bytes */
#ifdef  __TINY__
}      *RX_psp;
#else
} _far *RX_psp;
#endif

struct SHVBLOCK                         /****** SHV request block: ******/
{       struct SHVBLOCK _far *ShvNext;  /* ptr to next shvblock or NULL */
        struct RXSTR          ShvNam;   /* variable name                */
        struct RXSTR          ShvVal;   /* variable value               */
        unsigned int          ShvNamL;  /* returned length of name      */
        unsigned int          ShvValL;  /* returned length of value     */
        unsigned char         ShvCode;  /* shv function code            */
        unsigned char         ShvRet;   /* shv return code              */
};

static struct SHVBLOCK sb;

static char shvcode[  4 ];
static char shvnam[ 256 ];
static char shvval[ 256 ];
static char shvkeys[] = "SFDsfdnpx";

/* -------------------------------------------------------------------- */

#pragma intrinsic( memcmp, memcpy, memset, strcpy, strlen )
#pragma check_stack( off )

void _cdecl _nullcheck( void ) {}       /* no 0-pointer assignment test */
void _cdecl _setenvp( void )   {}       /* no operations on environment */
void _cdecl _setargv( void )   {}       /* no argc and argv processing  */

/* -------------------------------------------------------------------- */

int cgetb( char *response, unsigned size )
{
        memset( response, 0, size );
        response[ 0 ] = (unsigned char)( size - 2 );

        return strlen( strcpy( response, cgets( response )));
}
/* -------------------------------------------------------------------- */

int main( void )
{
        unsigned i, j;
        char alarm = 0;

#ifdef  __TINY__
        RX_psp = 0;

        if ( memcmp( RX_psp->Rexx, "REXX", 4 ))
#else
        RX_psp = MK_FP( _psp, 0 );

        if ( _fmemcmp( RX_psp->Rexx, (void _far *) "REXX", 4 ))
#endif
        {       cprintf( "REXX not found at %4.4X:0054\r\n", _psp );
                return 1;
        }
        /* ------------------------------------------------------------ */

        cprintf("Rexx Shared Variable Interface Test\r\n"
                "s symbolic set     S set   variable\r\n"
                "f symbolic fetch   F fetch variable\r\n"
                "d symbolic drop    D drop  variable\r\n"
                "n next  var.  (cycling through SHV)\r\n"
                "p fetch private info (e.g. VERSION)\r\n"
                "x set REXX exit code (doesn't work)\r\n" );

        for ( ;; )
        {
                if ( alarm ) putch( '\a' );
                memset( &sb, 0, sizeof sb );

                alarm = 1;
                cputs( "\r\nSHVCODE: " );
                if ( ! cgetb( shvcode, sizeof shvcode )) return 0;

                for ( i = 0; i < sizeof shvkeys; ++i )
                        if ( shvkeys[ i ] == *shvcode ) break;

                if ( sizeof shvkeys <= i ) continue;
                sb.ShvCode = (unsigned char) i;
                alarm = 0;

                if ( *shvcode != 'n' )
                {
                        cputs( "\r\nSHVNAM:  " );
                        sb.ShvNam.StrLen = cgetb( shvnam, sizeof shvnam );
                }
                else    sb.ShvNam.StrLen = sizeof shvnam;

                if ( *shvcode == 'S' || *shvcode == 's'
                ||   *shvcode == 'x' )
                {
                        cputs( "\r\nSHVVAL:  " );
                        sb.ShvVal.StrLen = cgetb( shvval, sizeof shvval );
                }
                else    sb.ShvVal.StrLen = sizeof shvval;

                sb.ShvNam.StrPtr = (char _far *) shvnam;
                sb.ShvVal.StrPtr = (char _far *) shvval;

                RX_psp->RXcall( &sb );          /* REXX call Shv entry  */

                cprintf("\r\nSHVRET:  %2.2X  (0 ok, 1 new, 2 last, "
                        "4 trunc, 8 inv, 10 no mem, 80 bad)"
                        "\r\nSHVNAML: %d   SHVVALL: %d\r\n",
                        (unsigned) sb.ShvRet, sb.ShvNamL, sb.ShvValL );

                if ( sb.ShvNamL )
                {       cputs( "SHVNAM:  " );

                        j = sb.ShvNamL;
                        if ( sizeof shvnam <= j ) j = sizeof shvnam;

                        for( i = 0; i < j; ++i )
                                putch( shvnam[ i ] );
                        cputs( "\r\n" );
                }

                if ( sb.ShvValL )
                {       cputs( "SHVVAL:  " );

                        j = sb.ShvValL;
                        if ( sizeof shvval <= j ) j = sizeof shvval;

                        for( i = 0; i < j; ++i )
                                putch( shvval[ i ] );
                        cputs( "\r\n" );
}       }       }
